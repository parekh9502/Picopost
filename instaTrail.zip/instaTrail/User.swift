//
//  User.swift
//  instaTrail
//
//  Created by Pritesh Parekh on 10/24/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit

class User: NSObject {
    
    var userID: String!
    var fullName: String!
    var imagePath: String!
    
}

